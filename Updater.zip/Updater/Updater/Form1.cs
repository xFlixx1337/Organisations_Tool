﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;
using System.IO;

namespace Updater
{
    public partial class UpdaterForm : Form
    {
        public UpdaterForm()
        {
            InitializeComponent();
        }
        //Variables
        private List<string> list = new List<string>();
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        private void closeBtn_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void formBorderPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void appNameLabel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void UpdaterForm_Load(object sender, EventArgs e)
        {
            Random rand = new Random();
            textTimer.Interval = rand.Next(1000,3000);
            list.Add("Adding Randomly Mispeled Words Into Text");
            list.Add("Creating Randomly Generated Feature");
            list.Add("Does Anyone Actually Read This?");
            list.Add("Loading, Don't Wait If You Don't Want To");
            list.Add("Sanding Wood Elves... now 34% smoother.");
            list.Add("Teaching Snakes to Kick");
            list.Add("Sharpening Swords");
            list.Add("Preparing to Spin You Around Rapidly");
            list.Add("Pizza...The Other Other White Meat");
            list.Add("Outfitting Pigs With Wings");
            list.Add("Now Spawning Fippy_Darkpaw_432,366,578");
            list.Add("Stealing all the data");
            list.Add("Dusting Off Spellbooks");
            list.Add("Generating Plans for Faster-Than-Light Travel");
            loadingBarTimer.Start();
            textTimer.Start();
            donloadStartTimer.Start();
        }

        private void loadingBarTimer_Tick(object sender, EventArgs e)
        {
            loadingBarTimer.Stop();
            Random rand = new Random();
            if(loadingBar.Value <= 90){loadingBar.Value += rand.Next(1, 30);}
            else { Environment.Exit(0); }
            loadingBarTimer.Start();
        }

        private void textTimer_Tick(object sender, EventArgs e)
        {
            textTimer.Stop();
            Random rand = new Random();
            loadingTextLabel.Text = list[rand.Next(0,list.Count)].ToString();
            loadingTextLabel.Location = new Point(360 - loadingTextLabel.Width / 2, loadingTextLabel.Location.Y);           
            textTimer.Interval = rand.Next(500, 1500);
            textTimer.Start();
        }
        private void DownloadNewVersion()
        {
            WebClient client = new WebClient();
            client.DownloadFile("https://github.com/xFlixx1337/Organisations_Tool/blob/main/DTR-Organisationstool.zip?raw=true", @"./temp.zip");
            ZipFile.ExtractToDirectory(@"./temp.zip", @"./");
            File.Delete(@"./temp.zip");
        }

        private void donloadStartTimer_Tick(object sender, EventArgs e)
        {
            DownloadNewVersion();
            donloadStartTimer.Stop();
        }
    }
}
