﻿namespace Updater
{
    partial class UpdaterForm
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdaterForm));
            this.formBorderPanel = new System.Windows.Forms.Panel();
            this.appNameLabel = new System.Windows.Forms.Label();
            this.closeBtn = new System.Windows.Forms.PictureBox();
            this.loadingBar = new System.Windows.Forms.ProgressBar();
            this.loadingBarTimer = new System.Windows.Forms.Timer(this.components);
            this.textTimer = new System.Windows.Forms.Timer(this.components);
            this.donloadStartTimer = new System.Windows.Forms.Timer(this.components);
            this.loadingTextLabel = new System.Windows.Forms.Label();
            this.formBorderPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // formBorderPanel
            // 
            this.formBorderPanel.BackColor = System.Drawing.Color.OrangeRed;
            this.formBorderPanel.Controls.Add(this.appNameLabel);
            this.formBorderPanel.Controls.Add(this.closeBtn);
            this.formBorderPanel.Location = new System.Drawing.Point(0, 0);
            this.formBorderPanel.Name = "formBorderPanel";
            this.formBorderPanel.Size = new System.Drawing.Size(720, 25);
            this.formBorderPanel.TabIndex = 0;
            this.formBorderPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.formBorderPanel_MouseMove);
            // 
            // appNameLabel
            // 
            this.appNameLabel.AutoSize = true;
            this.appNameLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appNameLabel.ForeColor = System.Drawing.Color.White;
            this.appNameLabel.Location = new System.Drawing.Point(3, 3);
            this.appNameLabel.Name = "appNameLabel";
            this.appNameLabel.Size = new System.Drawing.Size(59, 19);
            this.appNameLabel.TabIndex = 1;
            this.appNameLabel.Text = "Updater";
            this.appNameLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.appNameLabel_MouseMove);
            // 
            // closeBtn
            // 
            this.closeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeBtn.Image = ((System.Drawing.Image)(resources.GetObject("closeBtn.Image")));
            this.closeBtn.Location = new System.Drawing.Point(695, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(25, 25);
            this.closeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBtn.TabIndex = 0;
            this.closeBtn.TabStop = false;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // loadingBar
            // 
            this.loadingBar.Location = new System.Drawing.Point(12, 124);
            this.loadingBar.Name = "loadingBar";
            this.loadingBar.Size = new System.Drawing.Size(696, 23);
            this.loadingBar.TabIndex = 2;
            // 
            // loadingBarTimer
            // 
            this.loadingBarTimer.Interval = 1000;
            this.loadingBarTimer.Tick += new System.EventHandler(this.loadingBarTimer_Tick);
            // 
            // textTimer
            // 
            this.textTimer.Interval = 1000;
            this.textTimer.Tick += new System.EventHandler(this.textTimer_Tick);
            // 
            // donloadStartTimer
            // 
            this.donloadStartTimer.Interval = 2000;
            this.donloadStartTimer.Tick += new System.EventHandler(this.donloadStartTimer_Tick);
            // 
            // loadingTextLabel
            // 
            this.loadingTextLabel.AutoSize = true;
            this.loadingTextLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadingTextLabel.ForeColor = System.Drawing.Color.White;
            this.loadingTextLabel.Location = new System.Drawing.Point(200, 54);
            this.loadingTextLabel.Name = "loadingTextLabel";
            this.loadingTextLabel.Size = new System.Drawing.Size(320, 26);
            this.loadingTextLabel.TabIndex = 3;
            this.loadingTextLabel.Text = "Does anyone actually read this ?";
            // 
            // UpdaterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(720, 165);
            this.Controls.Add(this.loadingTextLabel);
            this.Controls.Add(this.loadingBar);
            this.Controls.Add(this.formBorderPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UpdaterForm";
            this.Text = "Updater";
            this.Load += new System.EventHandler(this.UpdaterForm_Load);
            this.formBorderPanel.ResumeLayout(false);
            this.formBorderPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel formBorderPanel;
        private System.Windows.Forms.PictureBox closeBtn;
        private System.Windows.Forms.Label appNameLabel;
        private System.Windows.Forms.ProgressBar loadingBar;
        private System.Windows.Forms.Timer loadingBarTimer;
        private System.Windows.Forms.Timer textTimer;
        private System.Windows.Forms.Timer donloadStartTimer;
        private System.Windows.Forms.Label loadingTextLabel;
    }
}

